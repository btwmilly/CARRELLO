# Carrello1
simulazione di un carrello in cui si possono aggiungere prodotti, eliminare prodotti e svuotare il carrello
